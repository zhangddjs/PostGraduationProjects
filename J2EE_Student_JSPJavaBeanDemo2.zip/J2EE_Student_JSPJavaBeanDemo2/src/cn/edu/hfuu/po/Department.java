/**
 * Department.java Create on Sep 13, 20124:32:05 PM
 * Copyright (c) 2011 by Big Z
 */
package cn.edu.hfuu.po;

/**
 *@description:
 *@author bigz
 *@version 1.0
 */

public class Department {
	private int id;
	private String code;
	private String name;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	

}
